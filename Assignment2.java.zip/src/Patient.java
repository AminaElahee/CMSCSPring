
public class Patient {
	
	//fields of attributes
	private String FirstName;
	private String MiddleName;
	private String LastName;
	
	private String Street;
	private String City;
	private String State;
	private String Zip;
	
	private String Phone;
	
	private String EmergencyName;
	private String EmergencyPhone;
	
	//No arg constructor
	public Patient()
	{	
		FirstName="No Firstname";
		MiddleName="No Middlename";
		LastName="No LastName";
		
		Street="No Street";
		City="No City";
		State="No State";
		Zip="0000";
		Phone="000-000-0000";
		
		EmergencyName= "No Emergency name";
		EmergencyPhone="000-000-0000";
		
	}
	
	//parametrized constructor
	public Patient(String fName, String mName, String lName)
	{
		FirstName=fName;
		MiddleName=mName;
		LastName=lName;
		
	}
	
	//parametrized constructor(for all attributes)
	public Patient(String fName, String mName, String lName, String street, String city,String state, String zip, String phone, String emergencyN,String emergencyPh )
	{
		FirstName=fName;
		MiddleName=mName;
		LastName=lName;
		Street=street;
		City=city;
		State=state;
		Zip=zip;
		Phone=phone;
		EmergencyName=emergencyN;
		EmergencyPhone=emergencyPh;
		
	}
	
	//accessor
		public String getFirstName()
		{
			return FirstName;
			 
		}
		public String getMiddleName()
		{
			
			return MiddleName;
			 
		}
		public String getLastName()
		{
			return LastName;
		}
		
		
		public String getStreet()
		{
			return Street;
			 
		}
		public String getCity()
		{
			return City;
			 
		}
		public String getState()
		{
			return State;
			 
		}
		public String getZip()
		{
			return Zip;
			 
		}
		public String getPhone()
		{
			return Phone;
		}
		public String getEmergencyName()
		{
			return EmergencyName;
		}
		public String getEmergencyPhone()
		{
			return EmergencyPhone;
		}
		
		
		//Mutator
		public void setFirstName(String fn)
		{
			FirstName=fn;
		}
		public void setMiddleName(String mn)
		{
			MiddleName=mn;
		}
		public void setLastName(String ln)
		{
			LastName=ln;
		}
		
		
		public void setStreet(String s)
		{
			Street=s;
		}
		
		public void setCity(String c)
		{
			City=c;
		}
		public void setState(String s)
		{
			State=s;
		}
		public void setZip(String z)
		{
			Zip=z;
		}
		
		public void setPhone(String p)
		{
			Phone=p;
		}
		
		public void setEmergencyName(String emN)
		{
			EmergencyName=emN;
		}
		public void setEmergencyPhone(String emP)
		{
			EmergencyPhone=emP;
		}
		

		
		public String buildName() //to return the full name
		{
			String a=FirstName+" "+ MiddleName+" "+ LastName;
			return a;
		}
		
		public String buildAddress() //to return the full address
		{
			String a=Street+" "+ City+" "+State+" "+ Zip;
			return a;
		}
		public String buildEmergencyContact()
		{
			String e=EmergencyName+" "+ EmergencyPhone;
			return e;
		}
		
		
		public String toString()
		{
			String n= "Name: "+ buildName()+"\n";
			String a= "Address: "+ buildAddress()+"\n";
			String e= "EmergencyContact: "+ buildEmergencyContact()+"\n";
			
			return "\t"+n+"\t"+a+"\t"+e;
		}
}
