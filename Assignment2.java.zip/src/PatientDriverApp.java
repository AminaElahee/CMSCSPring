/* Class: CMSC203 CRN 21525
 Program: Assignment 2
 Instructor: Khandan Vahabzadeh Monshi
 Summary of Description: Creating a Driver class
 Due Date: 10/08/2024 
 Integrity Pledge: I pledge that I have completed the programming assignment independently.
 I have not copied the code from a student or any source.
Student Name: Amine Elahee
 */


public class PatientDriverApp {

	public static void main(String[] args) {
		
		
		Patient p1=new Patient(); //creating an object
		
		//initiallizing the variables
	    String firstName = "Jenny";  	
	    String middleName = "Elaine";   
	    String lastName = "Santori";
	     
	    String streetAddress ="123 Main Street";
	    String city = "MyTown";	
	    String state = "CA";	 
	    String zipCode = "01234";
	    String phoneNumber ="123-436-7890";
	    String emergencyContactName = "Bill Santori";
	    String emergencyContactPhone = "777-555-1212";
		
	    
	    //setting up the values
	    p1.setFirstName(firstName);
	    p1.setMiddleName(middleName);
	    p1.setLastName(lastName);
	    p1.setStreet(streetAddress);
	    p1.setCity(city);
	    p1.setState(state);
	    p1.setZip(zipCode);
	    p1.setPhone(phoneNumber);
	    p1.setEmergencyName(emergencyContactName);
	    p1.setEmergencyPhone(emergencyContactPhone);
	    
	        
	    

	    
	    Procedure pro1 = new Procedure();//creating an object
	    
	    //setting the provided info to the object
        pro1.setNameOfProcedure("Physical Exam");
        pro1.setDateOfProcedure("10/08/2024");
        pro1.setNameOfPractitioner("Dr. Irvine");
        pro1.setCharges(3250.00);

        Procedure pro2 = new Procedure();
        pro2.setNameOfProcedure("X-Ray");
        pro2.setDateOfProcedure("10/08/2024");
        pro2.setNameOfPractitioner("Dr. Jamison");
        pro2.setCharges(5500.43);
        
        Procedure pro3 = new Procedure();
        pro3.setNameOfProcedure("Blood test");
        pro3.setDateOfProcedure("10/08/2024");
        pro3.setNameOfPractitioner("Dr. Smith");
        pro3.setCharges(1400.75);

        double totalCharges = calculateTotalCharges(pro1, pro2, pro3); //calling
        
        System.out.println("Patient Info:");
        
        System.out.println(p1);
        
    
        displayProcedure(pro1);
    
        displayProcedure(pro2);
        displayProcedure(pro3);
		
		
	   System.out.print("Total Charges: $"+totalCharges+"\n\n");
	   
		
	
		
		System.out.println("Student name: Amina Elahee");
		
		System.out.println("MC#: M21166734");
		
		System.out.print("Due Date: 10/08/2024");
		
		
		
	}
	//to display
	public static void displayPatient(Patient pa) 
	 {
		 System.out.println(pa);
	 }
	
	 public static void displayProcedure(Procedure p) 
	 {
		 System.out.println(p);
	 }
	 public static double calculateTotalCharges(Procedure proc1, Procedure proc2, Procedure proc3)
	 {
		 return proc1.getCharges() + proc2.getCharges() + proc3.getCharges();
	 
	 }
	 

}
