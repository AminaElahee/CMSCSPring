
public class Procedure {
// fields of attributes
	private String NameOfProcedure;
	private String DateOfProcedure;
	private String NameOfPractitioner;
	private double Charges;
	
	//no arg constructore
	public Procedure() //default values
	{
		NameOfProcedure="No Procedure name";
		DateOfProcedure="00/00/00";
		NameOfPractitioner="No Practitioner name";
		Charges=0.00;
		
	}
	
	//parametrized constructor
	public Procedure(String ProcedureName, String ProcedureDate)
	{
		NameOfProcedure=ProcedureName;
		DateOfProcedure=ProcedureDate;
		
	}
	//parametrized constructor
	public Procedure(String ProcedureName, String ProcedureDate, String PractitionerName , double c)
	{
		NameOfProcedure=ProcedureName;
		DateOfProcedure=ProcedureDate;
		NameOfPractitioner=PractitionerName;
		Charges=c;
	}
	
	
	//Accessor
	public String getNameOfProcedure()
	{
		return NameOfProcedure;
		 
	}
	public String getDateOfProcedure()
	{
		
		return DateOfProcedure;
		 
	}
	public String getNameOfPractitioner()
	{
		return NameOfPractitioner;
	}
	
	public double getCharges()
	{
		return Charges;
	}
	
	//Mutator
	public void setNameOfProcedure(String np)
	{
		 NameOfProcedure=np;
		 
	}
	public void setDateOfProcedure(String dp)
	{
		
		 DateOfProcedure=dp;
		 
	}
	public void setNameOfPractitioner(String np)
	{
		 NameOfPractitioner=np;
	}
	
	public void setCharges(double c)
	{
		 Charges=c;
	}
	
	
	public String toString()
	{
		String n= "Procedure: "+NameOfProcedure +"\n";
		String d= "ProcedureDate:= "+DateOfProcedure +"\n";
		String p= "Practitioner= "+ NameOfPractitioner+"\n";
		String c= "Charges= "+Charges+ "\n";
		
		return "\t"+n+"\t"+d+"\t"+p+"\t"+c;
	}
	
	
}
