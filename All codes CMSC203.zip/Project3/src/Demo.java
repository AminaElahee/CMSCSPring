
public class Demo {

	public static void main(String[] args) {
		
		CryptoManager cr=new CryptoManager();// you don't need this when method is defined as static
		System.out.println(cr.isStringInBounds("hi"));
		System.out.println(cr.isStringInBounds(CryptoManager.lower_ranh=ge);
		
	}
	
}
