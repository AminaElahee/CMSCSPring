
public class WithdrawOverflow extends Exception 
{
	public WithdrawOverflow(String Message)
	{
		super (Message);
	}

}
