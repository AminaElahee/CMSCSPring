import java.util.Scanner;

public class HelloWorld
{
	public static void main(String[] args)
	{
		System.out.println("Amina Elahee. I am 22 years old ");//one line
		
		System.out.print("Amina Elahee. ");//another way to write one line.
		System.out.println("I am 22 years old");
		
		int age=22;
		System.out.println("I am "+ age+ " years old");
		
		String name="Amina";
		System.out.println("My name is "+name);
		
		//increase your age by 1 using math operations
		
		System.out.println(age+1);
		// or 
		age++;
		System.out.println(age);
		
	
		if (age<20)
		{
			System.out.println("Young!");
		}
		else if(age>20 && age<50)
		{
			System.out.println("Let's live!");
		}
		else 
		{
			System.out.println("live live!");
		}
		
		//rewrite the if else with switch
		
		
		/*switch(age)
		{
		  case (age<20):
			  System.out.println("Young!");
			  
		    break;
		  case (age>20 && age<50):
			  System.out.println("Let's live!");
		    break;  
		  default:
			  System.out.println("live live!");
		}*/ //not sure
		
		//getting user input
		int num;
		
		System.out.print("Enter a number: ");
		
		Scanner in=new Scanner(System.in);
		num=in.nextInt();
		System.out.println(num);
		
	}
}
