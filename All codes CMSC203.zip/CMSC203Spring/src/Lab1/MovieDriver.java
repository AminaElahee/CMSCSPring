package Lab1;

import java.util.Scanner;

public class MovieDriver {

	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		
		String Movie=in.next();

	}

}
