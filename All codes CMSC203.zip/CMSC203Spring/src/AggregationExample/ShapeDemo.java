package AggregationExample;

public class ShapeDemo {

	public static void main(String[] args) {
		ColorCombination c1 = new ColorCombination(3,2,4);

		Shape p = new Shape("box", c1, 4);
	}

}
