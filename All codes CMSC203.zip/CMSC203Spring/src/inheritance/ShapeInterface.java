package inheritance;

public interface ShapeInterface 
{
	
//	All methods in the interface are public and abstract
	void rotate(int angle);
	public abstract void turnRight (int unit); 

}
