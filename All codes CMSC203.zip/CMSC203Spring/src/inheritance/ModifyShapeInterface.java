package inheritance;

public interface ModifyShapeInterface 
{
	
	public static final int MAX_SIZE = 20;
	public void erase();
	public void resize(int unit);

}
