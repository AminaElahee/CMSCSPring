package Session10;

public class Library {
	
	private String libName; 
	
	private String[] booksName;
	
	public Library()
	{
		libName = "NoName";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
