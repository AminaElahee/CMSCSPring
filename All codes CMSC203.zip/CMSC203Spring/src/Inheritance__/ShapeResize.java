package Inheritance__;

public interface ShapeResize {
	void shrink(int units);
	void enlarge(int units);
	
	
	

}
