package Inheritance__;

public interface ShapeRelocate {

	
	public abstract void MoveUp(int units);
	public abstract void MoveDown(int units);
	
	
	
	
	
}
