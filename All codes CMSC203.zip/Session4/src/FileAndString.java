import java.util.Scanner;
import java.io.File;

public class FileAndString {

	public static void main(String[] args)
	{
		/**
		 *  Implement the following 
		 *  Ask the user the enter the name of a file to read from.
		 *  Assume your files has the names of your friends each in one line
		 *  Your program should read a name from the file and show it on the screen using the following format:
		 *  name = "-----" , has "---" characters, the 3rd char is "----"
		 *  
		 *  Example:
		 *  Enter the name of the file: names.txt
		 *  name = Karen, has 5 characters, the 34d char is r 
		 */
		
		Scanner input = new Scanner (System.in);
		System.out.println("enter the name of the file:")
		String fileName = input.nextLine();
		System.out.println(fileName);
		
		while (fileRead.hasNext())
		{
			
		}
		
	}
	
	

}
