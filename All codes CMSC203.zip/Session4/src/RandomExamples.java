import java.util.Scanner;
import java.util.Random;


public class RandomExamples 
{
	public static void main(String[] args)
	{
//		Scanner input = new Scanner(System.in);
//		
//		System.out.println("Enter your age:");
//		int age = input.nextInt();
//		input.nextLine();
//		System.out.println("You entered " + age);
//		System.out.println(Integer.MAX_VALUE);
//		
//		System.out.println("Enter your name ");
//		
//		String name = input.nextLine();
//		
//		System.out.println("Your name is " + name);
//		
//		input.close();
		
		/*
		 * Create a random number between 1 and 10
		 */
		
		Random band = new Random();
		int randomNum = band.nextInt(1, 11); // Generates a number between 1 and 10
		System.out.println("Random Number: " + randomNum);

		


	}
	
}
