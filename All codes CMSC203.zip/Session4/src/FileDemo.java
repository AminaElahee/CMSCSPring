

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class FileDemo {

	public static void main(String[] args) throws FileNotFoundException 
	{
		
		File myFile = new File("names.txt");
		Scanner input = new Scanner(myFile); 
		String n = input.nextLine();
		System.out.println(n);
		
		input.close();
	}

}
