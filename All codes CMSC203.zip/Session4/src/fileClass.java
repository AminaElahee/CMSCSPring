package Session4;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class fileClass {

	public static void main(String[] args) throws FileNotFoundException 
	{
		
		File myFile = new File("names.txt");
		Scanner input = new Scanner(myFile); 
		int n = input.nextInt();
		System.out.println(Math.sqrt(n));
		
	}
	input.close();

}
