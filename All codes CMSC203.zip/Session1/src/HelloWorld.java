
public class HelloWorld
{
	public static void main(String[] args)
	{
		System.out.println("Amina Elahee");
		System.out.println("I am 22 years old");
	}
}
