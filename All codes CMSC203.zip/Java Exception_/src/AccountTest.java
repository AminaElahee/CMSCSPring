/**
   This program demonstrates how the BankAccount
   class constructor throws custom exceptions.
*/

public class AccountTest
{
   public static void main(String [] args)// throws NegativeStartingBalance
   {
      // Force a NegativeStartingBalance exception.
      try
      {
         BankAccount account =
                     new BankAccount(100.0);  //BankAccount account =new BankAccount(-100.0)-this will print out the message from catch
         
         System.out.println(account.getBalance());
         
       //  account.withdraw(200);
         account.withdraw(50);
         
         System.out.println(account.getBalance());
         
      }
      catch(NegativeStartingBalance e)
      {
         System.out.println(e.getMessage());
      }
      catch(InsuffBalanceException e)
      {
    	  System.out.println(e.getMessage());
    	  
      }
      finally 
      {
    	  System.out.println("In Finally block");
      }
      
      
      System.out.println("End of Main");
   }
}