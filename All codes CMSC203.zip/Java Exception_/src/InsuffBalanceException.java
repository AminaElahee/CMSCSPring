
public class InsuffBalanceException extends Exception{

	
	public InsuffBalanceException (String m)
	{
		super(m);
	}
	
	
	
}
