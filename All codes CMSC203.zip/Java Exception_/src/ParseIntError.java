/**
   This program demonstrates how the Integer.parseInt
   method throws an exception.
*/

public class ParseIntError
{
   public static void main(String[] args)
   {
      // String str = "abcde";
	   String str = "123";
       int number;
       int[] array = {1,2,3};
       
       
       try
       {
    	   int x=array[4];
    	  // int x=array[1];
          number = Integer.parseInt(str);
          System.out.println("we are still in Try!");
       }
   //    catch (NumberFormatException e)
//       catch (Exception e)   //we can also use that
//       { 
//          System.out.println("Conversion error: " +
//                             e.getMessage());
//       }
       
       catch (NumberFormatException e)  
       { 
          System.out.println("Conversion error: " +
                             e.getMessage());
       }
       
       catch (ArrayIndexOutOfBoundsException e)  
       { 
          System.out.println("Invalid Index " +
                             e.getMessage());
       }
       
       System.out.println("End of main");
   }
}